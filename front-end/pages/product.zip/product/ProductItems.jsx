import React from "react";

function Categories1() {
    return (
        <div>
            <h1></h1>
            <ul>
                    <li></li>
            </ul>
        </div>
    )
}

export default Categories1;