import React from 'react'
import PropTypes from 'prop-types'
import Categories1 from './ProductItems'

function Categories() {
    return (
        <div>
                {data.map((product) =>
                    <Categories1 
                    
                    />
                )
                }
        </div>
    )
}


export default Categories
